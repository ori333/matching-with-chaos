clc
clear
Exp1SPICEPlot( 'Exp1SPICEData.txt' )
