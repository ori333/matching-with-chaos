clc
clear
Sim2SPICEPlot( 'Sim2SPICEData.txt' )
